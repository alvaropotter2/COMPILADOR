# Archivo de prueba para estructuras de control
# If/else y while

numero = 15

if numero > 10
    puts "El número es mayor que 10"
else
    puts "El número es menor o igual que 10"
end

contador = 0
while contador < 5
    puts contador
    contador = contador + 1
end
