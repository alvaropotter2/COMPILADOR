# Archivo de prueba básico para el compilador Ruby -> MIPS
# Operaciones aritméticas básicas

x = 10
y = 20
z = x + y
puts z

# Operaciones con diferentes tipos
a = 5
b = 3
resultado = a * b - 2
puts resultado
