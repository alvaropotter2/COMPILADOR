#include "AST_ruby.h"
#include "tabla_simbolos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int contadorRegistros = 0;
static int contadorEtiquetas = 0;

// Crear nodo terminal para enteros
struct ast* crearNodoTerminal(int valor) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_NUMERO;
    nodo->valor.intVal = valor;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo terminal para floats
struct ast* crearNodoTerminalFloat(float valor) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_NUMERO;
    nodo->valor.floatVal = valor;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo terminal para strings
struct ast* crearNodoTerminalString(char* valor) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_STRING;
    nodo->valor.stringVal = strdup(valor);
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo terminal para booleanos
struct ast* crearNodoTerminalBool(int valor) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_BOOLEAN;
    nodo->valor.boolVal = valor;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo para variables
struct ast* crearVariableTerminal(void* valor, int registro) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_VARIABLE;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = registro;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo no terminal (operaciones binarias)
struct ast* crearNodoNoTerminal(struct ast* izq, struct ast* der, tipoNodo tipo) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = tipo;
    nodo->izquierdo = izq;
    nodo->derecho = der;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo unario
struct ast* crearNodoUnario(struct ast* hijo, tipoNodo tipo) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = tipo;
    nodo->izquierdo = hijo;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo de asignación
struct ast* crearNodoAsignacion(char* identificador, struct ast* expresion) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_ASIGNACION;
    nodo->valor.stringVal = strdup(identificador);
    nodo->izquierdo = NULL;
    nodo->derecho = expresion;
    nodo->siguiente = NULL;
    nodo->resultado = expresion->resultado;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo de asignación compuesta
struct ast* crearNodoAsignacionCompuesta(char* identificador, struct ast* expresion, tipoNodo operacion) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_ASIGNACION_COMPUESTA;
    nodo->valor.stringVal = strdup(identificador);
    nodo->izquierdo = expresion;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = expresion->resultado;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo puts
struct ast* crearNodoPuts(struct ast* expresion) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_PUTS;
    nodo->izquierdo = expresion;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = -1;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo condicional
struct ast* crearNodoCondicional(struct ast* condicion, struct ast* bloqueIf, struct ast* bloqueElse) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_CONDICIONAL;
    nodo->izquierdo = condicion;
    nodo->derecho = bloqueIf;
    nodo->siguiente = bloqueElse;
    nodo->resultado = -1;
    nodo->etiqueta = obtenerNuevaEtiqueta();
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo bucle
struct ast* crearNodoBucle(struct ast* condicion, struct ast* cuerpo) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_BUCLE;
    nodo->izquierdo = condicion;
    nodo->derecho = cuerpo;
    nodo->siguiente = NULL;
    nodo->resultado = -1;
    nodo->etiqueta = obtenerNuevaEtiqueta();
    nodo->linea = num_linea;
    return nodo;
}

// Crear nodo vacío
struct ast* crearNodoVacio() {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_VACIO;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = -1;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Funciones para Hito 2 - FUNCIONES
struct ast* crearNodoFuncion(char* nombre, struct ast* parametros, struct ast* cuerpo) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_FUNCION;
    nodo->valor.stringVal = strdup(nombre);
    nodo->izquierdo = parametros;
    nodo->derecho = cuerpo;
    nodo->siguiente = NULL;
    nodo->resultado = -1;
    nodo->etiqueta = obtenerNuevaEtiqueta();
    nodo->linea = num_linea;
    return nodo;
}

struct ast* crearNodoLlamadaFuncion(char* nombre, struct ast* argumentos) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_LLAMADA_FUNCION;
    nodo->valor.stringVal = strdup(nombre);
    nodo->izquierdo = argumentos;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

struct ast* crearNodoParametro(char* nombre) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_PARAMETRO;
    nodo->valor.stringVal = strdup(nombre);
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->siguiente = NULL;
    nodo->resultado = -1;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

struct ast* crearNodoAccesoArray(char* nombre, struct ast* indice1, struct ast* indice2) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_ACCESO_ARRAY;
    nodo->valor.stringVal = strdup(nombre);
    nodo->izquierdo = indice1;
    nodo->derecho = indice2;
    nodo->siguiente = NULL;
    nodo->resultado = obtenerNuevoRegistro();
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

struct ast* crearNodoAsignacionArray(char* nombre, struct ast* indice1, struct ast* indice2, struct ast* valor) {
    struct ast* nodo = (struct ast*)malloc(sizeof(struct ast));
    nodo->tipo = NODO_ASIGNACION_ARRAY;
    nodo->valor.stringVal = strdup(nombre);
    nodo->izquierdo = indice1;
    nodo->derecho = indice2;
    nodo->siguiente = valor;
    nodo->resultado = -1;
    nodo->etiqueta = NULL;
    nodo->linea = num_linea;
    return nodo;
}

// Funciones de utilidad
int obtenerNuevoRegistro() {
    return contadorRegistros++ % 8; // $t0 a $t7
}

char* obtenerNuevaEtiqueta() {
    char* etiqueta = (char*)malloc(20);
    sprintf(etiqueta, "L%d", contadorEtiquetas++);
    return etiqueta;
}

// Liberar memoria del AST
void liberarAST(struct ast* nodo) {
    if (nodo == NULL) return;
    
    liberarAST(nodo->izquierdo);
    liberarAST(nodo->derecho);
    liberarAST(nodo->siguiente);
    
    if (nodo->valor.stringVal && 
        (nodo->tipo == NODO_STRING || nodo->tipo == NODO_ASIGNACION || 
         nodo->tipo == NODO_FUNCION || nodo->tipo == NODO_LLAMADA_FUNCION || 
         nodo->tipo == NODO_PARAMETRO)) {
        free(nodo->valor.stringVal);
    }
    
    if (nodo->etiqueta) {
        free(nodo->etiqueta);
    }
    
    free(nodo);
}

// Imprimir AST
void imprimirAST(struct ast* nodo, int nivel) {
    if (nodo == NULL) return;
    
    for (int i = 0; i < nivel; i++) printf("  ");
    
    switch (nodo->tipo) {
        case NODO_NUMERO:
            printf("NUMERO: %d\n", nodo->valor.intVal);
            break;
        case SUMA:
            printf("SUMA\n");
            break;
        case RESTA:
            printf("RESTA\n");
            break;
        case MULTIPLICACION:
            printf("MULTIPLICACION\n");
            break;
        case DIVISION:
            printf("DIVISION\n");
            break;
        case MENOR_IGUAL:
            printf("MENOR_IGUAL\n");
            break;
        case NODO_ASIGNACION:
            printf("ASIGNACION: %s\n", nodo->valor.stringVal);
            break;
        case NODO_PUTS:
            printf("PUTS\n");
            break;
        case NODO_FUNCION:
            printf("FUNCION: %s\n", nodo->valor.stringVal);
            break;
        case NODO_LLAMADA_FUNCION:
            printf("LLAMADA_FUNCION: %s\n", nodo->valor.stringVal);
            break;
        case NODO_PARAMETRO:
            printf("PARAMETRO: %s\n", nodo->valor.stringVal);
            break;
        case NODO_RETURN:
            printf("RETURN\n");
            break;
        default:
            printf("NODO_TIPO_%d\n", nodo->tipo);
    }
    
    imprimirAST(nodo->izquierdo, nivel + 1);
    imprimirAST(nodo->derecho, nivel + 1);
    imprimirAST(nodo->siguiente, nivel + 1);
}

// Comprobar AST y generar código
void comprobarAST(struct ast* nodo) {
    if (nodo == NULL) return;
    
    printf("\n=== GENERANDO CÓDIGO MIPS COMPLETO ===\n");
    generarMIPSCompleto(nodo, "programa.rb");
    
    printf("\n=== AST CONSTRUIDO CORRECTAMENTE ===\n");
    imprimirAST(nodo, 0);
    imprimirTabla();
}

// Generación de código MIPS mejorada para funciones
void generarCodigoMIPS(struct ast* nodo) {
    if (nodo == NULL) return;
    
    switch(nodo->tipo) {
        case NODO_FUNCION:
            printf("# Definicion de funcion: %s\n", nodo->valor.stringVal);
            printf("%s:\n", nodo->valor.stringVal);
            printf("    # Prologo de funcion\n");
            printf("    addi $sp, $sp, -4\n");
            printf("    sw $ra, 0($sp)\n");
            
            // Generar código para el cuerpo
            generarCodigoMIPS(nodo->derecho);
            
            printf("    # Epilogo de funcion\n");
            printf("    lw $ra, 0($sp)\n");
            printf("    addi $sp, $sp, 4\n");
            printf("    jr $ra\n");
            break;
            
        case NODO_LLAMADA_FUNCION:
            printf("# Llamada a funcion: %s\n", nodo->valor.stringVal);
            
            // Generar código para argumentos
            generarCodigoMIPS(nodo->izquierdo);
            
            printf("    jal %s\n", nodo->valor.stringVal);
            break;
            
        case NODO_RETURN:
            printf("# Return statement\n");
            generarCodigoMIPS(nodo->izquierdo);
            printf("    move $v0, $t%d\n", nodo->izquierdo->resultado);
            printf("    j return_%s\n", "function"); // Simplificado
            break;
            
        default:
            // Para otros tipos de nodos, mantener la funcionalidad existente
            printf("# Generando código MIPS para nodo tipo %d\n", nodo->tipo);
            break;
    }
    
    generarCodigoMIPS(nodo->izquierdo);
    generarCodigoMIPS(nodo->derecho);
    generarCodigoMIPS(nodo->siguiente);
}

// Función auxiliar para verificar si un nodo es una definición de función
int esDefinicionFuncion(struct ast* nodo) {
    return nodo != NULL && nodo->tipo == NODO_FUNCION;
}

// Función principal para generar código principal (sin definiciones de funciones)
void generarCodigoPrincipal(struct ast* nodo, FILE* archivo) {
    if (nodo == NULL) return;
    
    switch(nodo->tipo) {
        case NODO_FUNCION:
            // No generar código aquí, ya se generó en generarDefinicionesFunciones
            return;
            
        case NODO_NUMERO:
            fprintf(archivo, "    # Cargar numero: %d\n", nodo->valor.intVal);
            fprintf(archivo, "    li $t%d, %d\n", nodo->resultado, nodo->valor.intVal);
            break;
            
        case NODO_VARIABLE:
        case NODO_IDENTIFICADOR:
            if (nodo->valor.stringVal && strlen(nodo->valor.stringVal) > 0) {
                int valid = 1;
                for (int i = 0; i < strlen(nodo->valor.stringVal); i++) {
                    if (nodo->valor.stringVal[i] < 32 || nodo->valor.stringVal[i] > 126) {
                        valid = 0;
                        break;
                    }
                }
                
                if (valid) {
                    fprintf(archivo, "    # Cargar variable: %s\n", nodo->valor.stringVal);
                    fprintf(archivo, "    lw $t%d, var_%s\n", nodo->resultado, nodo->valor.stringVal);
                }
            }
            break;
            
        case SUMA:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            fprintf(archivo, "    # Suma\n");
            fprintf(archivo, "    add $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case RESTA:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            fprintf(archivo, "    # Resta\n");
            fprintf(archivo, "    sub $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case MULTIPLICACION:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            fprintf(archivo, "    # Multiplicacion\n");
            fprintf(archivo, "    mul $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case DIVISION:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            fprintf(archivo, "    # Division\n");
            fprintf(archivo, "    div $t%d, $t%d\n", nodo->izquierdo->resultado, nodo->derecho->resultado);
            fprintf(archivo, "    mflo $t%d\n", nodo->resultado);
            break;
            
        case MENOR_IGUAL:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            fprintf(archivo, "    # Comparacion menor o igual\n");
            fprintf(archivo, "    sle $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case NODO_ASIGNACION:
            generarCodigoPrincipal(nodo->derecho, archivo);
            if (nodo->valor.stringVal && strlen(nodo->valor.stringVal) > 0) {
                fprintf(archivo, "    # Asignacion a %s\n", nodo->valor.stringVal);
                fprintf(archivo, "    sw $t%d, var_%s\n", nodo->derecho->resultado, nodo->valor.stringVal);
            }
            break;
            
        case NODO_PUTS:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            fprintf(archivo, "    # Imprimir valor\n");
            fprintf(archivo, "    move $a0, $t%d\n", nodo->izquierdo->resultado);
            fprintf(archivo, "    li $v0, 1            # Print integer\n");
            fprintf(archivo, "    syscall\n");
            fprintf(archivo, "    la $a0, newline      # Print newline\n");
            fprintf(archivo, "    li $v0, 4\n");
            fprintf(archivo, "    syscall\n");
            break;
            
        case NODO_LLAMADA_FUNCION:
            if (nodo->valor.stringVal && strlen(nodo->valor.stringVal) > 0) {
                fprintf(archivo, "    # Llamada a funcion: %s\n", nodo->valor.stringVal);
                
                // Generar código para argumentos y pasarlos en registros $a0, $a1, etc.
                struct ast* arg = nodo->izquierdo;
                int arg_reg = 0;
                while (arg != NULL && arg_reg < 4) {
                    generarCodigoPrincipal(arg, archivo);
                    fprintf(archivo, "    move $a%d, $t%d\n", arg_reg, arg->resultado);
                    arg = arg->siguiente;
                    arg_reg++;
                }
                
                fprintf(archivo, "    jal %s\n", nodo->valor.stringVal);
                fprintf(archivo, "    move $t%d, $v0       # Guardar resultado\n", nodo->resultado);
            }
            break;
            
        case NODO_RETURN:
            fprintf(archivo, "    # Return statement\n");
            if (nodo->izquierdo) {
                generarCodigoPrincipal(nodo->izquierdo, archivo);
                fprintf(archivo, "    move $v0, $t%d\n", nodo->izquierdo->resultado);
            }
            return;
            
        case NODO_CONDICIONAL:
            if (nodo->izquierdo && nodo->derecho && nodo->etiqueta) {
                fprintf(archivo, "    # Condicional\n");
                generarCodigoPrincipal(nodo->izquierdo, archivo);
                fprintf(archivo, "    beqz $t%d, %s_else\n", nodo->izquierdo->resultado, nodo->etiqueta);
                generarCodigoPrincipal(nodo->derecho, archivo);
                fprintf(archivo, "    j %s_end\n", nodo->etiqueta);
                fprintf(archivo, "%s_else:\n", nodo->etiqueta);
                if (nodo->siguiente) {
                    generarCodigoPrincipal(nodo->siguiente, archivo);
                }
                fprintf(archivo, "%s_end:\n", nodo->etiqueta);
            }
            return;
            
        case NODO_BUCLE:
            if (nodo->izquierdo && nodo->derecho && nodo->etiqueta) {
                fprintf(archivo, "    # Bucle\n");
                fprintf(archivo, "%s_start:\n", nodo->etiqueta);
                generarCodigoPrincipal(nodo->izquierdo, archivo);
                fprintf(archivo, "    beqz $t%d, %s_end\n", nodo->izquierdo->resultado, nodo->etiqueta);
                generarCodigoPrincipal(nodo->derecho, archivo);
                fprintf(archivo, "    j %s_start\n", nodo->etiqueta);
                fprintf(archivo, "%s_end:\n", nodo->etiqueta);
            }
            return;
            
        case NODO_SECUENCIA:
            generarCodigoPrincipal(nodo->izquierdo, archivo);
            generarCodigoPrincipal(nodo->derecho, archivo);
            return;
            
        default:
            break;
    }
    
    // Procesar hermanos solo para nodos que no manejan recursión especial
    if (nodo->tipo != NODO_CONDICIONAL && nodo->tipo != NODO_BUCLE && 
        nodo->tipo != NODO_SECUENCIA && nodo->tipo != NODO_FUNCION &&
        nodo->tipo != NODO_RETURN) {
        generarCodigoPrincipal(nodo->siguiente, archivo);
    }
}

// Función auxiliar para generar código de función con parámetros correctos
void generarCodigoFuncion(struct ast* nodo, FILE* archivo) {
    if (nodo == NULL) return;
    
    static int param_counter = 0;
    
    switch(nodo->tipo) {
        case NODO_NUMERO:
            fprintf(archivo, "    # Cargar numero: %d\n", nodo->valor.intVal);
            fprintf(archivo, "    li $t%d, %d\n", nodo->resultado, nodo->valor.intVal);
            break;
            
        case NODO_PARAMETRO:
        case NODO_IDENTIFICADOR:
            // Para parámetros, usar registros $a0, $a1, etc.
            if (nodo->valor.stringVal) {
                fprintf(archivo, "    # Parametro %s (desde $a%d)\n", nodo->valor.stringVal, param_counter % 4);
                fprintf(archivo, "    move $t%d, $a%d\n", nodo->resultado, param_counter % 4);
                param_counter++;
                if (nodo->siguiente == NULL) param_counter = 0; // Reset para próxima función
            }
            break;
            
        case SUMA:
            generarCodigoFuncion(nodo->izquierdo, archivo);
            generarCodigoFuncion(nodo->derecho, archivo);
            fprintf(archivo, "    # Suma\n");
            fprintf(archivo, "    add $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case RESTA:
            generarCodigoFuncion(nodo->izquierdo, archivo);
            generarCodigoFuncion(nodo->derecho, archivo);
            fprintf(archivo, "    # Resta\n");
            fprintf(archivo, "    sub $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case MULTIPLICACION:
            generarCodigoFuncion(nodo->izquierdo, archivo);
            generarCodigoFuncion(nodo->derecho, archivo);
            fprintf(archivo, "    # Multiplicacion\n");
            fprintf(archivo, "    mul $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case MENOR_IGUAL:
            generarCodigoFuncion(nodo->izquierdo, archivo);
            generarCodigoFuncion(nodo->derecho, archivo);
            fprintf(archivo, "    # Comparacion menor o igual\n");
            fprintf(archivo, "    sle $t%d, $t%d, $t%d\n", 
                   nodo->resultado, nodo->izquierdo->resultado, nodo->derecho->resultado);
            break;
            
        case NODO_RETURN:
            fprintf(archivo, "    # Return statement\n");
            if (nodo->izquierdo) {
                generarCodigoFuncion(nodo->izquierdo, archivo);
                fprintf(archivo, "    move $v0, $t%d\n", nodo->izquierdo->resultado);
            }
            return;
            
        case NODO_CONDICIONAL:
            if (nodo->izquierdo && nodo->derecho && nodo->etiqueta) {
                fprintf(archivo, "    # Condicional\n");
                generarCodigoFuncion(nodo->izquierdo, archivo);
                fprintf(archivo, "    beqz $t%d, %s_else\n", nodo->izquierdo->resultado, nodo->etiqueta);
                generarCodigoFuncion(nodo->derecho, archivo);
                fprintf(archivo, "    j %s_end\n", nodo->etiqueta);
                fprintf(archivo, "%s_else:\n", nodo->etiqueta);
                if (nodo->siguiente) {
                    generarCodigoFuncion(nodo->siguiente, archivo);
                }
                fprintf(archivo, "%s_end:\n", nodo->etiqueta);
            }
            return;
            
        case NODO_LLAMADA_FUNCION:
            if (nodo->valor.stringVal && strlen(nodo->valor.stringVal) > 0) {
                fprintf(archivo, "    # Llamada a funcion: %s\n", nodo->valor.stringVal);
                
                struct ast* arg = nodo->izquierdo;
                int arg_reg = 0;
                while (arg != NULL && arg_reg < 4) {
                    generarCodigoFuncion(arg, archivo);
                    fprintf(archivo, "    move $a%d, $t%d\n", arg_reg, arg->resultado);
                    arg = arg->siguiente;
                    arg_reg++;
                }
                
                fprintf(archivo, "    jal %s\n", nodo->valor.stringVal);
                fprintf(archivo, "    move $t%d, $v0       # Guardar resultado\n", nodo->resultado);
            }
            break;
            
        default:
            break;
    }
    
    // Procesar hermanos
    if (nodo->tipo != NODO_CONDICIONAL && nodo->tipo != NODO_RETURN) {
        generarCodigoFuncion(nodo->siguiente, archivo);
    }
}

// Función auxiliar para generar todas las definiciones de funciones (corregida)
void generarDefinicionesFunciones(struct ast* nodo, FILE* archivo) {
    if (nodo == NULL) return;
    
    if (nodo->tipo == NODO_FUNCION) {
        if (nodo->valor.stringVal && strlen(nodo->valor.stringVal) > 0) {
            fprintf(archivo, "# Definicion de funcion: %s\n", nodo->valor.stringVal);
            fprintf(archivo, "%s:\n", nodo->valor.stringVal);
            fprintf(archivo, "    # Prologo de funcion\n");
            fprintf(archivo, "    addi $sp, $sp, -8\n");
            fprintf(archivo, "    sw $ra, 4($sp)\n");
            fprintf(archivo, "    sw $fp, 0($sp)\n");
            fprintf(archivo, "    move $fp, $sp\n");
            
            // Generar código para el cuerpo de la función usando la función específica
            generarCodigoFuncion(nodo->derecho, archivo);
            
            fprintf(archivo, "    # Epilogo de funcion\n");
            fprintf(archivo, "    move $sp, $fp\n");
            fprintf(archivo, "    lw $fp, 0($sp)\n");
            fprintf(archivo, "    lw $ra, 4($sp)\n");
            fprintf(archivo, "    addi $sp, $sp, 8\n");
            fprintf(archivo, "    jr $ra\n\n");
        }
    }
    
    // Buscar recursivamente más funciones
    generarDefinicionesFunciones(nodo->izquierdo, archivo);
    generarDefinicionesFunciones(nodo->derecho, archivo);
    generarDefinicionesFunciones(nodo->siguiente, archivo);
}

// Función principal para generar código MIPS en archivo
void generarCodigoMIPSArchivo(struct ast* nodo, FILE* archivo) {
    if (nodo == NULL) return;
    
    // Primero, saltar sobre las definiciones de funciones
    fprintf(archivo, "    j programa_principal\n\n");
    
    // Generar todas las definiciones de funciones
    generarDefinicionesFunciones(nodo, archivo);
    
    // Etiqueta del programa principal
    fprintf(archivo, "programa_principal:\n");
    
    // Generar código principal (sin funciones)
    generarCodigoPrincipal(nodo, archivo);
}