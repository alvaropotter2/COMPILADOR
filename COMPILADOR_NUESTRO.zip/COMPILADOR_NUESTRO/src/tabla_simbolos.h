#ifndef TABLA_SIMBOLOS_H
#define TABLA_SIMBOLOS_H

#include "AST_ruby.h"

// Estructura para la tabla de símbolos
typedef struct {
    char* nombre;           // Nombre del identificador
    char* tipo;             // Tipo: "integer", "float", "string", "boolean"
    int integer;            // Valor si es entero
    float floatDecimal;     // Valor si es float
    char* string;           // Valor si es string
    int boolean;            // Valor si es boolean (0 o 1)
    int registro;           // Registro MIPS asignado ($t0, $t1, etc.)
    int direccion;          // Dirección en memoria
    int inicializada;       // Si la variable ha sido inicializada (0 o 1)
} tSimbolos;

// Variables globales
extern tSimbolos tabla[256];  // Tabla de símbolos
extern int indice;            // Índice actual en la tabla
extern int num_linea;         // Número de línea actual

// Prototipos de funciones
int buscarTabla(int indice, char* nombre, tSimbolos tabla[]);
int agregarSimbolo(char* nombre, char* tipo);
void inicializarTabla();
void imprimirTabla();
char* obtenerRegistro(int pos);
void liberarTabla();

#endif
