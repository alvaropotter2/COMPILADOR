#include "tabla_simbolos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef _WIN32
#include <unistd.h>
#else
#define _POSIX_C_SOURCE 200809L
#endif

// Variables globales
tSimbolos tabla[256];
int indice = 0;
// num_linea se define en ruby_lexer.flex, no aquí

// Inicializar la tabla de símbolos
void inicializarTabla() {
    for (int i = 0; i < 256; i++) {
        tabla[i].nombre = NULL;
        tabla[i].tipo = NULL;
        tabla[i].integer = 0;
        tabla[i].floatDecimal = 0.0;
        tabla[i].string = NULL;
        tabla[i].boolean = 0;
        tabla[i].registro = -1;
        tabla[i].direccion = -1;
        tabla[i].inicializada = 0;
    }
}

// Buscar un símbolo en la tabla
int buscarTabla(int indice, char* nombre, tSimbolos tabla[]) {
    for (int i = 0; i < indice; i++) {
        if (tabla[i].nombre != NULL && strcmp(tabla[i].nombre, nombre) == 0) {
            return i;
        }
    }
    return -1; // No encontrado
}

// Agregar un símbolo a la tabla
int agregarSimbolo(char* nombre, char* tipo) {
    if (indice >= 256) {
        fprintf(stderr, "Error: Tabla de símbolos llena\n");
        return -1;
    }
    
    // Verificar si ya existe
    if (buscarTabla(indice, nombre, tabla) != -1) {
        fprintf(stderr, "Error: Variable '%s' ya declarada\n", nombre);
        return -1;
    }
    
    // Función auxiliar para duplicar strings
    char* duplicar_string(const char* str) {
        char* nuevo = malloc(strlen(str) + 1);
        if (nuevo) strcpy(nuevo, str);
        return nuevo;
    }
    
    tabla[indice].nombre = duplicar_string(nombre);
    tabla[indice].tipo = duplicar_string(tipo);
    tabla[indice].registro = indice % 8; // $t0 a $t7
    tabla[indice].direccion = indice * 4; // Dirección en memoria
    tabla[indice].inicializada = 0;
    
    return indice++;
}

// Obtener registro MIPS
char* obtenerRegistro(int pos) {
    static char* registros[] = {
        "$t0", "$t1", "$t2", "$t3", "$t4", "$t5", "$t6", "$t7"
    };
    
    if (pos >= 0 && pos < 8) {
        return registros[pos];
    }
    return "$t0"; // Valor por defecto
}

// Imprimir tabla de símbolos
void imprimirTabla() {
    printf("\n=== TABLA DE SÍMBOLOS ===\n");
    printf("%-15s %-10s %-10s %-10s\n", "Nombre", "Tipo", "Valor", "Registro");
    printf("================================================\n");
    
    for (int i = 0; i < indice; i++) {
        if (tabla[i].nombre != NULL) {
            printf("%-15s %-10s ", tabla[i].nombre, tabla[i].tipo);
            
            if (strcmp(tabla[i].tipo, "integer") == 0) {
                printf("%-10d ", tabla[i].integer);
            } else if (strcmp(tabla[i].tipo, "float") == 0) {
                printf("%-10.2f ", tabla[i].floatDecimal);
            } else if (strcmp(tabla[i].tipo, "string") == 0) {
                printf("%-10s ", tabla[i].string ? tabla[i].string : "NULL");
            } else if (strcmp(tabla[i].tipo, "boolean") == 0) {
                printf("%-10s ", tabla[i].boolean ? "true" : "false");
            }
            
            printf("%s\n", obtenerRegistro(tabla[i].registro));
        }
    }
    printf("\n");
}

// Liberar memoria de la tabla
void liberarTabla() {
    for (int i = 0; i < indice; i++) {
        if (tabla[i].nombre) free(tabla[i].nombre);
        if (tabla[i].tipo) free(tabla[i].tipo);
        if (tabla[i].string) free(tabla[i].string);
    }
}