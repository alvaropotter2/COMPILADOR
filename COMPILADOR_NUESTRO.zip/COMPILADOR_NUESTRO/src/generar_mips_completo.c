#include "AST_ruby.h"
#include "tabla_simbolos.h"
#include "tabla_simbolos_funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void generarMIPSCompleto(struct ast* nodo, const char* nombreArchivo) {
    FILE* archivo = fopen("ruby.asm", "w");
    if (!archivo) {
        fprintf(stderr, "Error: No se pudo crear el archivo ruby.asm\n");
        return;
    }
    
    fprintf(archivo, "# Codigo MIPS generado por el compilador Ruby -> MIPS\n");
    fprintf(archivo, "# Archivo fuente: %s\n", nombreArchivo);
    fprintf(archivo, "# Generado automaticamente\n\n");
    
    // Seccion de datos
    fprintf(archivo, ".data\n");
    fprintf(archivo, "    newline: .asciiz \"\\n\"\n");
    
    // Generar variables de la tabla de simbolos (evitar duplicados)
    int variables_generadas[256] = {0}; // Array para marcar variables ya generadas
    
    for (int i = 0; i < indice; i++) {
        if (tabla[i].nombre != NULL && !variables_generadas[i]) {
            // Marcar esta variable como generada
            variables_generadas[i] = 1;
            
            // Verificar si hay duplicados y marcarlos también
            for (int j = i + 1; j < indice; j++) {
                if (tabla[j].nombre != NULL && strcmp(tabla[i].nombre, tabla[j].nombre) == 0) {
                    variables_generadas[j] = 1;
                    // Actualizar valor si es necesario (tomar el último valor asignado)
                    if (strcmp(tabla[j].tipo, "integer") == 0) {
                        tabla[i].integer = tabla[j].integer;
                    }
                }
            }
            
            if (strcmp(tabla[i].tipo, "integer") == 0) {
                fprintf(archivo, "    var_%s: .word %d\n", tabla[i].nombre, tabla[i].integer);
            } else if (strcmp(tabla[i].tipo, "string") == 0) {
                fprintf(archivo, "    str_%s: .asciiz \"%s\"\n", tabla[i].nombre, 
                       tabla[i].string ? tabla[i].string : "");
            }
        }
    }
    
    fprintf(archivo, "\n.text\n");
    fprintf(archivo, ".globl main\n\n");
    
    // IMPORTANTE: Asegurar que main esté presente
    fprintf(archivo, "main:\n");
    fprintf(archivo, "    # Inicio del programa principal\n");
    
    // Generar código para el AST
    if (nodo != NULL) {
        generarCodigoMIPSArchivo(nodo, archivo);
    } else {
        // Si no hay nodo, generar código mínimo
        fprintf(archivo, "    # Programa vacío\n");
        fprintf(archivo, "    li $t0, 42\n");
        fprintf(archivo, "    move $a0, $t0\n");
        fprintf(archivo, "    li $v0, 1\n");
        fprintf(archivo, "    syscall\n");
        fprintf(archivo, "    la $a0, newline\n");
        fprintf(archivo, "    li $v0, 4\n");
        fprintf(archivo, "    syscall\n");
    }
    
    fprintf(archivo, "\n    # Terminar programa\n");
    fprintf(archivo, "    li $v0, 10           # Syscall para exit\n");
    fprintf(archivo, "    syscall              # Terminar programa\n");
    
    fclose(archivo);
    
    printf("El archivo ruby.asm ha sido creado exitosamente.\n");
    printf("Puedes ejecutarlo en MARS (MIPS Assembly and Runtime Simulator)\n\n");
    
    printf("=== CODIGO MIPS GENERADO EN ruby.asm ===\n");
    printf("=== COMPILACION COMPLETADA EXITOSAMENTE ===\n");
}
